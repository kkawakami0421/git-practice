require 'test_helper'

class HonesControllerTest < ActionDispatch::IntegrationTest
  test "should get start" do
    get hones_start_url
    assert_response :success
  end

end
