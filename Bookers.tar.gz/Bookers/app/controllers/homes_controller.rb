class HomesController < ApplicationController
  def start
  end
end
